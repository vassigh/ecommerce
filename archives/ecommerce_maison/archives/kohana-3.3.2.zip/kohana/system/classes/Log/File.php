<?php defined('SYSPATH') OR die('No direct script access.');

class Log_File extends Kohana_Log_File {}
