<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_412 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 412 Precondition Failed
	 */
	protected $_code = 412;

}
