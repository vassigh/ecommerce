<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_501 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 501 Not Implemented
	 */
	protected $_code = 501;

}
